# Attendance Calculator

A Pen created on CodePen.

Original URL: [https://codepen.io/abxwucrp-the-sans/pen/GgRWMNZ](https://codepen.io/abxwucrp-the-sans/pen/GgRWMNZ).

